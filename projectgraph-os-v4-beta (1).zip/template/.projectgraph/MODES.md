# Modes

| Mode | Phases | Gates | Agents | First agent |
|------|--------|-------|--------|-------------|
| mvp | Discover → Build → Verify | Release | Maya, Forge, Sentinel | Maya |
| research | Discover → Validate | None | Maya, Nova | Maya |
| ai-rag | All 5 | Design + Release | All 5 | Maya |
| saas | All 5 | Design + Release | All 5 | Maya |
| repo-rescue | Design → Build → Verify | Recovery plan | Atlas, Forge, Sentinel | Atlas |

Default: mvp. Set Mode in CONTEXT.md. Heavier modes are opt-in.
