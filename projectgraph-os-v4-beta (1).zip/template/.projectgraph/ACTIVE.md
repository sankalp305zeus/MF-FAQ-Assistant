# Active

Phase: discover
Agent: Maya
Mode: mvp

## Objective
[Starting. Fill CONTEXT.md then activate Maya.]

## Last handoff
File: none
Summary: Project not yet started.

## Last decision
None.

## Blocker
None.

## Next
[Describe the problem you want to solve.]
