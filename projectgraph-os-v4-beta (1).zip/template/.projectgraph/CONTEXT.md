# Context

## Identity
- Name:
- Slug:
- One-liner:
- Type: [product | research | experiment | internal-tool]
- Stage: [idea | prototype | mvp | growth | mature]
- Mode: mvp

## Problem
<!-- max 40 words -->

## Solution
<!-- max 40 words -->

## Constraints
-

## Rules
<!-- Conventions any agent must follow on this project. Max 4. -->
-

## Assumptions (unvalidated)
<!-- Agents treat as uncertain. -->
-
